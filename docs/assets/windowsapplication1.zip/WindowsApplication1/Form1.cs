using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace WindowsApplication1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			me = this.Handle;
			timer1.Enabled=true;
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(96, 216);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(80, 24);
			this.button1.TabIndex = 0;
			this.button1.Text = "down";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(224, 120);
			this.label1.TabIndex = 1;
			this.label1.Text = "label1";
			// 
			// timer1
			// 
			this.timer1.Interval = 1000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(176, 168);
			this.button2.Name = "button2";
			this.button2.TabIndex = 2;
			this.button2.Text = "right";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(88, 144);
			this.button3.Name = "button3";
			this.button3.TabIndex = 3;
			this.button3.Text = "up";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(8, 184);
			this.button4.Name = "button4";
			this.button4.TabIndex = 4;
			this.button4.Text = "left";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		[ DllImport("user32.dll") ]
		static extern IntPtr GetForegroundWindow(); 

		[DllImportAttribute("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, 
			int Msg, int wParam, int lParam);

		[DllImportAttribute("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

		[DllImport("user32.dll", ExactSpelling = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
		private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int cx, int cy, bool repaint);

		private IntPtr me;
		private IntPtr window;
		private int posx=1;
		private int posy=1;
		private int sizex=100;
		private int sizey=100;

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			IntPtr temp  = GetForegroundWindow();
			if( me != temp)
			{			
				window = temp;
				label1.Text = window.ToString();

				RECT t = new RECT();
				bool r = GetWindowRect(window, out t);

				posx = t.Location.X;
				posy = t.Location.Y;
				sizex = t.Width;
				sizey = t.Height;
				label1.Text = label1.Text + "\nx: "  + t.Location.X+ "\ny: " + t.Location.Y
					+"\nwidth: "+sizex + "\nheight: " + sizey;
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			//right
			posx = posx +10;
			MoveWindow((IntPtr)window, posx, posy , sizex, sizey, true);
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
		//left
			posx = posx -10;
			MoveWindow((IntPtr)window, posx, posy , sizex, sizey, true);
		}
		private void button1_Click(object sender, System.EventArgs e)
		{
			//down
			posy = posy +10;
			MoveWindow((IntPtr)window, posx, posy , sizex, sizey, true);
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			//up
			posy = posy -10;
			MoveWindow((IntPtr)window, posx, posy , sizex, sizey, true);
		}
	}

	[Serializable, StructLayout(LayoutKind.Sequential)]
	public struct RECT 
	{
		public int Left;
		public int Top;
		public int Right;
		public int Bottom;

		public RECT(int left_, int top_, int right_, int bottom_) 
		{
			Left = left_;
			Top = top_;
			Right = right_;
			Bottom = bottom_;
		}

		public int Height { get { return Bottom - Top; } }
		public int Width { get { return Right - Left; } }
		public Size Size { get { return new Size(Width, Height); } }

		public Point Location { get { return new Point(Left, Top); } }

		// Handy method for converting to a System.Drawing.Rectangle
		public Rectangle ToRectangle()
		{ return Rectangle.FromLTRB(Left, Top, Right, Bottom); }

		public static RECT FromRectangle(Rectangle rectangle) 
		{
			return new RECT(rectangle.Left, rectangle.Top, rectangle.Right, rectangle.Bottom);
		}

		public override int GetHashCode() 
		{
			return Left ^ ((Top << 13) | (Top >> 0x13))
				^ ((Width << 0x1a) | (Width >> 6))
				^ ((Height << 7) | (Height >> 0x19));
		}

		#region Operator overloads

		public static implicit operator Rectangle( RECT rect )
		{
			return rect.ToRectangle();      
		}

		public static implicit operator RECT( Rectangle rect )
		{
			return FromRectangle(rect);
		}

		#endregion
	}
}
